To install the driver, right click on RNDIS.inf and click �Install�.

This driver is downloaded from 
http://download.windowsupdate.com/msdownload/update/driver/drvs/2011/01/20342321_32450c5ebb31a11d277d97836264223a430aa06d.cab